from django.contrib import admin
from myapp.models import Person

@admin.register(Person) # ใส่ไว้ตรงนี้เลย ไม่ต้องสั่ง register ด้านล่างแล้ว
class PersonAdmin(admin.ModelAdmin):
    list_display = ('name', 'age')