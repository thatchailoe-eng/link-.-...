from django.shortcuts import render, redirect
from django.http import HttpResponse
from myapp.models import Person

# Create your views here.
def index(request):
  all_person = Person.objects.all()
  return render(request,"index.html",{"all_person":all_person})

def about(request):
    return render(request,"about.html")


def form(request):
  if request.method == "POST":
      name = request.POST.get("name")
      age = request.POST.get("age")
      if name and age:
          Person.objects.create(name=name, age=age)
          return redirect('about')
  return render(request,"form.html")

def edit(request, id):
    person = Person.objects.get(id=id)
    if request.method == "POST":
        person.name = request.POST.get("name")
        person.age = request.POST.get("age")
        if person.name and person.age:
            person.save()
            return redirect('index')
    return render(request, "edit.html", {"person": person})

def delete(request, id):
    person = Person.objects.get(id=id)
    person.delete()
    return redirect('about')