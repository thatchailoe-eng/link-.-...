from django.db import models

class Person(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    date = models.DateField(auto_now_add=True)
  
    # ต้องมี Tab (ย่อหน้า) เข้ามาให้ตรงกับ Field ด้านบน
    def __str__(self):
        return f"{self.name}, {self.age} years old"
    

  