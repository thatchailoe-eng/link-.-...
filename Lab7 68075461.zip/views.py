from django.shortcuts import render
from django.http import HttpResponse

# หน้าแรก
def index(request):
    return HttpResponse("<h1>หน้าแรกของเว็บไซต์</h1>")

# หน้าเกี่ยวกับเรา
def about(request):
    return HttpResponse("<h1>เกี่ยวกับเรา</h1>")

# ข้อ 2: แสดงหน้าแบบฟอร์มจากไฟล์ form.html (Assignment 7)
def form(request):
    return render(request, 'form.html')

# ข้อ 1: แสดงข้อมูลติดต่อ (Assignment 7)
def contact(request):
    # ข้อมูลของคุณ: 68038275 นายกนกพล ภูมิชิน
    return HttpResponse("<h1>ติดต่อ: 68038275 นายกนกพล ภูมิชิน</h1>")

