from django.urls import path
from . import views

urlpatterns = [
    # หน้าหลักเดิม
    path('', views.index, name='index'),
    
    # หน้า About (แนะนำให้ใส่ / ปิดท้าย)
    path('about/', views.about, name='about'),

    # ข้อ 1: กำหนด URL /contact/
    path('contact/', views.contact, name='contact'),
    
    # ข้อ 2: กำหนด URL /form/ 
    # (หมายเหตุ: ในโค้ดเดิมคุณพิมพ์ 'from/' ซึ่งอาจทำให้สับสน ควรใช้ 'form/' ตามโจทย์ครับ)
    path('form/', views.form, name='form'),
]
